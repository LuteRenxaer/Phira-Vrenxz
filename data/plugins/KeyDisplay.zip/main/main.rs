fn on_frame(ctx, settings) {
    let p = ctx.panel;
    let x = p.x; let y = p.y; let w = p.w; let h = p.h;
    let accent = settings.color;
    let bg_alpha = settings.background;
    let alpha = settings.opacity;
    let rows = [["Q","W","E","R","T","Y","U","I","O","P"], ["A","S","D","F","G","H","J","K","L"], ["Z","X","C","V","B","N","M"]];
    let out = [#{x:x,y:y,w:w,h:h,radius:0.025,color:0x0A0C12,alpha:bg_alpha*alpha,text:""}, #{x:x,y:y,w:w,h:0.052,radius:0.02,color:0x30384A,alpha:alpha,text:""}];
    let top = y + 0.075;
    let row_h = (h - 0.095) / 4.0;
    for r in 0..3 {
        let n = rows[r].len();
        let key_w = (w - 0.05 - (n - 1) * 0.008) / n;
        let start = x + 0.025;
        for i in 0..n {
            let key = rows[r][i];
            let on = ctx.keys.contains(key);
            let color = if on { accent } else { 0x232833 };
            out.push(#{x:start + i * (key_w + 0.008), y:top + r * row_h, w:key_w, h:row_h - 0.012, radius:0.012, color:color, alpha:alpha, text:key});
        }
    }
    let space_w = w * 0.5;
    let space_x = x + (w - space_w) / 2.0;
    let space_y = top + 3.0 * row_h;
    let space_on = ctx.keys.contains("SPACE");
    let space_color = if space_on { accent } else { 0x232833 };
    out.push(#{x:space_x, y:space_y, w:space_w, h:row_h - 0.012, radius:0.012, color:space_color, alpha:alpha, text:"SPACE"});
    out
}
